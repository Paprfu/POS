#include "Food.h"



Food::Food(SDL_Window * window):
	Object(0, 0, FOOD_HEIGHT, FOOD_WIDTH,0,0)
{
	eaten = true;
	
	
}


Food::~Food()
{
}

void Food::render(SDL_Renderer * ren)
{
	SDL_SetRenderDrawColor(ren, 200, 200, 200, 255);
	SDL_RenderFillRect(ren, &dest);
}

void Food::update(int maxH, int maxW)
{
	if(eaten) {

		this->posX = rand() % maxW;
		this->posY = rand() % maxH;
		eaten = false;

	}
	this->setDest(posX, posY, height, width);
}



#pragma once


#define SNAKE_INIT_X 100
#define SNAKE_INIT_Y 100
#define SNAKE_INIT_H 30
#define SNAKE_INIT_W 30
#define SNAKE_INIT_MOVEX 10
#define SNAKE_INIT_MOVEY 0
#define SNAKE_SPEED 10

#define FOOD_HEIGHT 15
#define FOOD_WIDTH 15

enum Directions {
	UP,
	DOWN,
	LEFT,
	RIGHT
};
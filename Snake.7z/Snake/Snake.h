#pragma once
#include "Object.h"
#include "defines.h"

#ifndef SNAKE_H
#define SNAKE_H

#include <iostream>
#include <SDL.h>
#include <SDL_image.h>

class Snake :
	public Object
{
public:
	Snake();
	~Snake();
	void changeDirection(Directions direction);

	virtual void render(SDL_Renderer * ren);
	virtual void update(int maxH, int maxW);
};

#endif
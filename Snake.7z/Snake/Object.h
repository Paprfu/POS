#pragma once
#ifndef OBJECT_H
#define OBJECT_H

#include <iostream>
#include <SDL.h>
#include <SDL_image.h>

using namespace std;

class Object
{
protected:
	SDL_Rect dest;
	SDL_Rect src;
	SDL_Texture * tex;
	int moveX;
	int moveY;
	int posX;
	int posY;
	int height;
	int width;

public:
	Object();
	Object(int x, int y, int h, int w, int moveX, int moveY);
	SDL_Rect getDest() const { return dest; }
	SDL_Rect getSrc() const { return src; }
	SDL_Texture * getTex() const { return tex; }
	void setDest(int x, int y, int w, int h);
	void setSource(int x, int y, int w, int h);
	void setImage(string filename, SDL_Renderer * renderer);
	virtual void render(SDL_Renderer * renderer) = 0;
	virtual void update(int maxH, int maxW) = 0;


	~Object();
};

#endif //OBJECT_H
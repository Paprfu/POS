#pragma once
#ifndef GAME_H
#define GAME_H

#include <iostream>
#include <algorithm>
#include <vector>
#include <SDL.h>
#include <SDL_image.h>
#include "Object.h"
#include "Snake.h"
#include "Food.h"

using namespace std;


class Game
{
private:
	SDL_Renderer * renderer;
	SDL_Window * window;
	bool running;
	int count, maxWinH, maxWinW;
	int frameCount, timeFPS, lastFrame;
	//vector<Object*> * objects;

	Snake * snake;
	Food * food;
public:
	Game();

	void loop();
	void update() ;
	void input() ;
	void render();



	~Game();
};


#endif //GAME_H


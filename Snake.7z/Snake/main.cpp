#include "Game.h"
#undef main

int main() {
	Game g;
	return -1;
}
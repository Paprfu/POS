#pragma once
#include "Object.h"
#include "Snake.h"
#include "defines.h"

#ifndef FOOD_H
#define FOOD_H

#include <iostream>
#include <SDL.h>
#include <SDL_image.h>


class Food:
	public Object
{
private:
	bool eaten;
public:
	Food(SDL_Window * window);
	~Food();

	virtual void render(SDL_Renderer *ren);
	virtual void update(int maxH, int maxW);
	
};

#endif //FOOD.H
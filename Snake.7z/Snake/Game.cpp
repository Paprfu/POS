#include "Game.h"


Game::Game()
{
	SDL_Init(0);
	SDL_CreateWindowAndRenderer(0, 0, 0, &window, &renderer);
	SDL_MaximizeWindow(window);
	SDL_SetWindowTitle(window, "Snake");
	SDL_SetWindowInputFocus(window);
	
	SDL_GetWindowSize(window, &maxWinW ,&maxWinH);

	this->snake = new Snake();
	this->food = new Food(window);
	this->running = true;
	this->count = 0;
	this->loop();

}

void Game::loop() {
	while (running) {

		lastFrame = SDL_GetTicks();
		static int lastTime;
		if (lastFrame >= (lastTime + 1000)) {
			lastTime = lastFrame;
			frameCount = 0;
			count++;
		}
		
		this->render();
		this->input();
		this->update();
		
		
	}
}

void Game::update()
{
	this->snake->update(maxWinH, maxWinW);
	this->food->update(maxWinH, maxWinW);
}

void Game::input()
{
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		std::cout << event.type << endl;
		switch (event.type) {
			case SDL_MOUSEMOTION:
				break;
			case SDL_MOUSEBUTTONDOWN:
				break;
			case SDL_KEYUP:	
				snake->changeDirection(Directions::DOWN); 
				break;
			case SDL_KEYDOWN:
				snake->changeDirection(Directions::UP); 
				break;
			case SDLK_LEFT:
				snake->changeDirection(Directions::LEFT); 
				break;
			case SDLK_RIGHT:
				snake->changeDirection(Directions::RIGHT); 
				break;

			case SDL_QUIT: 
				this->running = false; 
				break;
			default: return;
		}
	}
		switch (event.key.keysym.sym)
		{
		case SDLK_ESCAPE: running = true; break;
		}
}


void Game::render() {
	SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
	SDL_Rect rect;
	rect.x = rect.y = 0;
	SDL_GetWindowSize(window, &rect.w, &rect.h);
	SDL_RenderFillRect(renderer, &rect);

	this->snake->render(renderer);
	this->food->render(renderer);

	frameCount++;
	int timerFPS = SDL_GetTicks() - lastFrame;
	if (timerFPS < (1000 / 60)) {
		SDL_Delay((1000 / 60) - timerFPS);
	}

	SDL_RenderPresent(renderer);
}


















Game::~Game()
{
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	
}

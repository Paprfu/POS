#include "Snake.h"

Snake::Snake() :
	Object(SNAKE_INIT_X, SNAKE_INIT_Y, SNAKE_INIT_H, SNAKE_INIT_W, SNAKE_INIT_MOVEX, SNAKE_INIT_MOVEY)
{
}


Snake::~Snake()
{
}

void Snake::changeDirection(Directions direction)
{

	switch (direction) {
	case Directions::UP:
		if (this->moveX <= 0){
			this->moveX = 0;
			this->moveY = (-1*SNAKE_SPEED);
			}
		break;
	case Directions::DOWN: 
		if (this->moveY >= 0) {
			this->moveX = 0;
			this->moveY = SNAKE_SPEED;
		}
		  break;
		  case Directions::RIGHT: 
			  if (this->moveX >= 0) {
					this->moveY = 0;
					this->moveX = SNAKE_SPEED;
			  }
		break;
		case Directions::LEFT: 
			if (this->moveX <= 0) {
				this->moveY = 0;
				this->moveX = (-1*SNAKE_SPEED);
			}
		  break;
	}
}

void Snake::render(SDL_Renderer * ren)
{
	SDL_SetRenderDrawColor(ren, 50, 50, 50, 255);
	SDL_RenderFillRect(ren, &dest);
}

void Snake::update(int maxH, int maxW)
{
	this->posX += moveX;
	this->posY += moveY;

	if (posX > maxW) {
		posX = 0;
	}
	else if (posY > maxH) {
		posY = 0;
	}
	else if (posX < 0) {
		posX = maxW;

	}
	else if (posY < 0) {
		posY = maxH;
	}

	this->setDest(posX, posY, height, width);
}

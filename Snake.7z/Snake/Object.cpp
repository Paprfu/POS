#include "Object.h"



Object::Object()
{
	
}

Object::Object(int x, int y, int h, int w, int moveX, int moveY)
{
	this->posX = x;
	this->posY = y;
	this->height = h;
	this->width = w;
	this->moveX = moveX;
	this->moveY = moveY;
	setDest(x, y, h, w);
}

void Object::setDest(int x, int y, int w, int h)
{
	dest.x = x;
	dest.y = y;
	dest.w = w;
	dest.h = h;
}

void Object::setSource(int x, int y, int w, int h)
{
	src.x = x;
	src.y = y;
	src.w = w;
	src.h = h;
}

void Object::setImage(string filename, SDL_Renderer * renderer)
{
	SDL_Surface * surf = IMG_Load(filename.c_str());
	tex = SDL_CreateTextureFromSurface(renderer, surf);
}



Object::~Object()
{
}
